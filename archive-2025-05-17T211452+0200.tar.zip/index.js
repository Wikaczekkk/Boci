const { Client, GatewayIntentBits, Collection, REST, Routes, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Token i inne stałe
const TOKEN = 'MTMxNzM5NjgwNTM5NDM3MDY1Mg.G0QXDP.XFIa8cwbh3mqY8li7vpewCAaQrgtTE4TxrAuvo';
const GUILD_ID = '1222811178854649946';
const VERIFY_ROLE_ID = '1285250745658114168';
const STAFF_ROLE_ID = '1276554777257443388';
const CATEGORY_SUPPORT = '1363165254762102866';

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers]
});

// === Ładowanie komend ===
client.commands = new Collection();
const commands = [];
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const command = require(path.join(commandsPath, file));
        if (command.data && command.execute) {
            client.commands.set(command.data.name, command);
            commands.push(command.data.toJSON());
        }
    }
}

// === Po zalogowaniu ===
client.once('ready', async () => {
    console.log(`✅ Zalogowano jako ${client.user.tag}`);
    const rest = new REST({ version: '10' }).setToken(TOKEN);
    try {
        await rest.put(Routes.applicationGuildCommands(client.user.id, GUILD_ID), { body: commands });
        console.log('✅ Komendy załadowane!');
    } catch (err) {
        console.error(err);
    }
});

// === Obsługa interakcji ===
client.on('interactionCreate', async interaction => {
    if (interaction.isCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (command) {
            try {
                await command.execute(interaction);
            } catch (err) {
                console.error(err);
                await interaction.reply({ content: '❌ Błąd wykonania komendy!', ephemeral: true });
            }
        }
    } else if (interaction.isButton()) {
        if (interaction.customId === 'verify') {
            await handleVerifyButton(interaction);
        } else if (interaction.customId === 'create_ticket') {
            await handleCreateTicket(interaction);
        } else if (interaction.customId === 'close_ticket') {
            await handleCloseTicket(interaction);
        }
    } else if (interaction.isModalSubmit() && interaction.customId === 'ticket_form') {
        await handleTicketForm(interaction);
    }
});

// === Funkcje obsługi ===
async function handleVerifyButton(interaction) {
    const role = interaction.guild.roles.cache.get(VERIFY_ROLE_ID);
    if (!role) return interaction.reply({ content: '❌ Rola nie istnieje!', ephemeral: true });
    if (interaction.member.roles.cache.has(VERIFY_ROLE_ID)) {
        return interaction.reply({ content: '✅ Już masz tę rolę!', ephemeral: true });
    }
    await interaction.member.roles.add(role);
    await interaction.reply({ content: '✅ Zweryfikowano!', ephemeral: true });
}

async function handleCreateTicket(interaction) {
    const modal = new ModalBuilder()
        .setCustomId('ticket_form')
        .setTitle('Formularz Ticketa');

    modal.addComponents(
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('nick').setLabel('Server').setStyle(TextInputStyle.Short)
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('description').setLabel('Opis problemu').setStyle(TextInputStyle.Paragraph)
        ),
        new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('category').setLabel('Kategoria (Pomoc/Skarga/Unban)').setStyle(TextInputStyle.Short)
        )
    );

    await interaction.showModal(modal);
}

async function handleTicketForm(interaction) {
    const nick = interaction.fields.getTextInputValue('nick');
    const description = interaction.fields.getTextInputValue('description');
    const category = interaction.fields.getTextInputValue('category');

    function formatCategory(input) {
        switch (input.toLowerCase()) {
            case 'pomoc': return '🔧 Pomoc Techniczna';
            case 'skarga': return '⚠️ Skarga na gracza';
            case 'unban': return '📜 Prośba o unbana';
            default: return '❓ Nieznana kategoria';
        }
    }

    const ticketChannel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0,
        parent: CATEGORY_SUPPORT,
        permissionOverwrites: [
            { id: interaction.guild.roles.everyone.id, deny: ['ViewChannel'] },
            { id: interaction.user.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'] },
            { id: STAFF_ROLE_ID, allow: ['ViewChannel', 'SendMessages', 'ManageChannels', 'ReadMessageHistory'] }
        ]
    });

    await interaction.reply({ content: `✅ Ticket utworzony: <#${ticketChannel.id}>`, ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(`🎫 Ticket - ${nick}`)
        .addFields(
            { name: 'Server', value: nick },
            { name: 'Opis', value: description },
            { name: 'Kategoria', value: formatCategory(category) }
        )
        .setColor('#424242')
        .setThumbnail('https://cdn.discordapp.com/attachments/1362860724313133307/1362860899781575027/a28c1f4d31bb86786b998f51c6fe4815_kopia.gif?ex=6803ee9f&is=68029d1f&hm=0442e7e76cae3a9e04fac26523cdca6370c8598fda313fc0840faf64570d9062&')
        .setFooter({ text: `Utworzony przez: ${interaction.user.tag}` });

    const closeButton = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('Zamknij Ticket')
            .setStyle(ButtonStyle.Danger)
    );

    await ticketChannel.send({ embeds: [embed], components: [closeButton] });
}

async function handleCloseTicket(interaction) {
    await interaction.reply({ content: '⏳ Zamykam ticket za 5 sekund...', ephemeral: true });
    setTimeout(() => interaction.channel.delete(), 5000);
}


// === Logowanie bota ===
client.login(TOKEN);
