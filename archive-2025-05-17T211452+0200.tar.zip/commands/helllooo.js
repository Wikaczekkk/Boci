const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers, // Wymaga tego, aby móc śledzić dołączających użytkowników
    ]
});

const WELCOME_CHANNEL_ID = '1363825854211428484'; // ID kanału powitalnego, na który wysyłana będzie wiadomość
const SERVER_NAME = 'Silly Shop™ - NEW!'; // Nazwa Twojego serwera
const SERVER_ID = '1222811178854649946'; // ID Twojego serwera

client.once('ready', () => {
    console.log(`Zalogowano jako ${client.user.tag}`);
});

client.on('guildMemberAdd', async (member) => {
    // Sprawdzamy, czy użytkownik dołączył do właściwego serwera
    if (!member.guild || member.guild.id !== SERVER_ID) return;

    // Pobieramy aktualną liczbę członków na serwerze
    const memberCount = member.guild.memberCount;

    // Tworzymy powitalną wiadomość
    const welcomeMessage = `Witaj @${member.user.username} :3 na serwerze ${SERVER_NAME}!`;

    // Wysyłanie wiadomości na określony kanał
    const channel = await member.guild.channels.fetch(WELCOME_CHANNEL_ID).catch(() => null);
    if (channel) {
        const embed = new EmbedBuilder()
            .setTitle('Nowy Gracz!')
            .setColor('#424242')
            .setDescription(welcomeMessage)
            .addFields(
                { name: 'Cieszymy się, że jesteś z nami!', value: `Aktualnie na serwerze jest ${memberCount} graczy!`, inline: false }
            )
            .setFooter({ text: `Witaj : @${member.user.username}`, iconURL: member.user.displayAvatarURL() });

        // Wysyłamy embed na kanał powitalny
        channel.send({ embeds: [embed] }).catch(console.error);
    }
});

client.login('MTMxNzM5NjgwNTM5NDM3MDY1Mg.G0QXDP.XFIa8cwbh3mqY8li7vpewCAaQrgtTE4TxrAuvo'); // Pamiętaj, aby wstawić swój prawdziwy token bota!
