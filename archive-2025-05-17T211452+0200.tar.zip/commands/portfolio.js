const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

// Lista kreatywnych powitań
const POWITANIA = [
	"Cześć! Nadciąga nowy projekt!",
	"Oto najnowsza praca, zerknij na to!",
	"Boom! Świeża kreacja właśnie przed Tobą!",
	"Coś nowego, coś wyjątkowego — oto efekt naszej pracy!",
	"Przygotuj się, bo nadchodzi kolejny sztos!",
	"Masz ochotę na dawkę inspiracji? Spójrz na to!",
	"Kolejne arcydzieło trafia do portfolio!",
	"Niech Twoje oczy chłoną to dzieło!"
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('portfolio')
        .setDescription('Dodaj nowe portfolio')
        .addStringOption(option =>
            option.setName('wykonanie')
                .setDescription('Kto wykonał pracę?')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('dla')
                .setDescription('Dla kogo została wykonana praca?')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('url')
                .setDescription('URL obrazu')
                .setRequired(true)),
                
    async execute(interaction) {
        const wykonanie = interaction.options.getString('wykonanie');
        const dla = interaction.options.getString('dla');
        const url = interaction.options.getString('url');

        const powitanie = POWITANIA[Math.floor(Math.random() * POWITANIA.length)];

        const embed = new EmbedBuilder()
            .setColor('#d3dbca')
            .setTitle('<:Bez_nazwy6_Odzyskano:1347715955840782466> NanoCore ・ᴘᴏʀᴛꜰᴏʟɪᴏ')
            .setDescription(`${powitanie}`)
            .addFields(
                { name: ' Wykonanie:', value: wykonanie, inline: true },
                { name: ' Dla:', value: dla, inline: true }
            )
            .setImage(url)
            .setThumbnail('https://cdn.discordapp.com/attachments/1344658863965733016/1347715550528278608/Bez_nazwy-6_Odzyskano_kopia.gif?ex=67ccd56a&is=67cb83ea&hm=86394983bb911857811ec3d6dcf8ac7e0657ea7647f53c4377190da35acc5ec8&');

        const message = await interaction.reply({ embeds: [embed], fetchReply: true });
        await message.react('<:done:1340300422753161267>');
        await message.react('<:deny:1340300420962189383>');
    }
};
