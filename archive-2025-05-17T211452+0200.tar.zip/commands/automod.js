const { Client, GatewayIntentBits, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, 'config.json');
if (!fs.existsSync(configPath)) {
    console.error('Brak pliku config.json!');
    process.exit(1);
}
const { token } = require(configPath);

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

const AUTO_MUTE_TIME = 300; // Czas w sekundach
const LINK_REGEX = /(https?:\/\/|www\.)[\w\d./?=#]+/gi;
const ALLOWED_ROLE_ID = '1353732333483593758';

client.once('ready', () => {
    console.log(`Zalogowano jako ${client.user.tag}`);
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;
    
    if (message.member.roles.cache.has(ALLOWED_ROLE_ID)) return;
    
    if (LINK_REGEX.test(message.content)) {
        try {
            await message.delete();
            
            const warnMessage = await message.author.send('Wysylanie linkow jest zabronione!');
            setTimeout(() => warnMessage.delete().catch(() => {}), 300000);
            
            if (message.member.moderatable) {
                await message.member.timeout(AUTO_MUTE_TIME * 1000, 'Wysylanie linkow');
                const muteMessage = await message.author.send(`Zostales wyciszony na ${AUTO_MUTE_TIME} sekund.`);
                setTimeout(() => muteMessage.delete().catch(() => {}), 300000);
            }
        } catch (error) {
            console.error('B��d podczas mutowania u�ytkownika:', error);
        }
    }
});
