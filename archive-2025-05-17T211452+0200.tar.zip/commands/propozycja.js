const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('propozycje')
        .setDescription('Dodaje propozycję użytkownika.')
        .addStringOption(option => 
            option.setName('tekst')
                .setDescription('Treść propozycji')
                .setRequired(true)
        ),
    async execute(interaction) {
        const allowedChannelId = '1353405087518556244'; // ID dozwolonego kanału
        if (interaction.channelId !== allowedChannelId) {
            return interaction.reply({ content: 'Ta komenda może być używana tylko na określonym kanale!', ephemeral: true });
        }
        
        const proposalText = interaction.options.getString('tekst');
        const user = interaction.user;
        
        const embed = new EmbedBuilder()
            .setColor('#424242')
            .setTitle('📩 Nowa propozycja')
            .setDescription(`**Propozycja użytkownika:** ${user}

${proposalText}`)
            .setTimestamp();
        
        const message = await interaction.reply({ embeds: [embed], fetchReply: true });
        
        // Reakcje do głosowania
        await message.react('✅');
        await message.react('❌');
    },
};
