const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration
    ]
});

const LOG_CHANNEL_ID = '1275749394263576588'; // ID kana�u log�w
const EXEMPT_ROLE_ID = '1353732333483593758'; // ID roli zwolnionej z filtr�w
const EXEMPT_CHANNELS = [ // Kana�y wy��czone z automoderacji
    '1354471431467040972',
    '1354472120637456506',
    '1354097974975664231',
    '1354472269870792835',
    '1354472907635556632'
];

const BANNED_WORDS = [
    'geju', 'chuj', 'chuja', 'chujek', 'chuju', 'chujem', 'chujnia', 'https://', 'chujowy', 
    'chujowa', 'chujowe', 'cipa', 'cip ', 'cipe', 'cipie', 'dojeba ', 'dojebac', 'dojebie', 
    'dupa', 'dupie', 'dup ', 'dupcia', 'dupeczka', 'dupy', 'dupe', 'huj', 'hujek', 'hujnia',
    'jebac', 'jebal', 'jebie', 'jebany', 'jebana', 'jebani', 'jebanych', 'jebanymi',
    'kurwa', 'kurwy', 'kurewski', 'kurwo', 'kutas', 'kutasa', 'kutasie', 'kutasem', 'kutasy'
];

client.once('ready', () => {
    console.log(`Zalogowano jako ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
    if (!message.guild || message.author.bot) return;

    // Sprawdzanie, czy wiadomo�� pochodzi z wykluczonych kana��w
    if (EXEMPT_CHANNELS.includes(message.channel.id)) {
        return;
    }

    // Sprawdzanie, czy u�ytkownik ma rol� zwolnion� z filtr�w
    const member = await message.guild.members.fetch(message.author.id).catch(() => null);
    if (member && member.roles.cache.has(EXEMPT_ROLE_ID)) {
        return;
    }

    // Sprawdzanie, czy wiadomo�� zawiera zakazane s�owa
    const containsBannedWord = BANNED_WORDS.some(word => message.content.toLowerCase().includes(word));
    
    if (containsBannedWord) {
        await message.delete().catch(console.error);
        console.log(`Usuni�to wiadomo�� zawieraj�c� zakazane s�owa: "${message.content}"`);
        
        const logChannel = await message.guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
        if (logChannel) {
            const embed = new EmbedBuilder()
                .setTitle('Filtr czatu - Usuni�ta wiadomo��')
                .setColor('#ff0000')
                .addFields(
                    { name: 'U�ytkownik', value: `<@${message.author.id}>`, inline: true },
                    { name: 'ID U�ytkownika', value: message.author.id, inline: true },
                    { name: 'Kana�', value: `<#${message.channel.id}>`, inline: true },
                    { name: 'Tre�� wiadomo�ci', value: message.content || 'Brak tre�ci', inline: false },
                    { name: 'Czas', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                )
                .setFooter({ text: 'System Moderacji', iconURL: client.user.displayAvatarURL() });
            
            logChannel.send({ embeds: [embed] }).catch(console.error);
        }

        if (member) {
            try {
                await member.timeout(5 * 60 * 1000, 'U�ycie zakazanych s��w.').catch(console.error);
                console.log(`U�ytkownik <@${message.author.id}> zosta� wyciszony na 5 minut.`);
            } catch (error) {
                console.error('B��d podczas nadawania muta:', error);
            }
        }
    }
});

client.login('MTMxNzM5NjgwNTM5NDM3MDY1Mg.G0QXDP.XFIa8cwbh3mqY8li7vpewCAaQrgtTE4TxrAuvo'); // Pami�taj, aby wstawi� sw�j prawdziwy token bota!
