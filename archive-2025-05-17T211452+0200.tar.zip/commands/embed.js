const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Wysyła embed w stylu cennika.'),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor('#d3dbca')
            .setTitle('📌 NanoCore ・ CENNIK')
            .setDescription('**🎨 Grafika**\n' +
                '- Miniaturka = 15zł\n' +
                '- Avatar = 15zł\n' +
                '- Banner = 25zł\n\n' +
                '**📂 Branding**\n' +
                '- Sygnet = 70zł\n' +
                '- Logotyp = 40zł\n' +
                '- Mascot Logo = 70zł\n' +
                '- Logo (Vector) = 100zł\n\n' +
                '**🎬 Montaż filmu / Animacja**\n' +
                '- Animacja 2D - 1s/5zł\n' +
                '- Wstęp 30s - 20zł\n' +
                '- Montaż filmu - 1m/15zł\n' +
                '- Cięcia filmu (1h materiału) - 25-30zł'
            )
            .setThumbnail('https://example.com/your-image.png') // Możesz tu dodać URL do miniaturki
            .setFooter({ text: 'Cennik usług NanoCore' });

        await interaction.reply({ embeds: [embed] });
    },
};
