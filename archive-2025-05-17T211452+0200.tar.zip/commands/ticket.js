const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Wysy a panel do tworzenia ticket w'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle(' Wikak zamowienia - Ticket')
            .setDescription('> Aby utworzyc ticket musisz kliknac przycisk na dole.')
            .setColor('#424242');

        const button = new ButtonBuilder()
            .setCustomId('create_ticket')
            .setLabel('Zamow')
            .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder().addComponents(button);

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};
