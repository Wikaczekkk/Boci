const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js');
const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});

client.on('messageCreate', async (message) => {
    if (message.content.toLowerCase() === '!reg') {
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📜 Regulamin Serwera Discord')
            .setDescription('Witamy na naszym serwerze! Przed rozpoczęciem korzystania z naszej społeczności prosimy o zapoznanie się z poniższymi zasadami.\n\n' +
                '**1️⃣ Szanuj innych**\n' +
                'Bądź miły i szanuj innych użytkowników. Żadne formy hejtu, agresji czy wulgaryzmów nie będą tolerowane.\n' +
                'Zachowuj się w sposób uprzedzający. Wszyscy mamy różne poglądy i perspektywy, szanuj to.\n\n' +
                '**2️⃣ Treści**\n' +
                'Nie publikuj treści nieodpowiednich, wulgarnych ani szkodliwych.\n' +
                'Pornografia, przemoc, nienawiść i dyskryminacja są absolutnie zabronione. 🚫\n' +
                'Sprawdzaj, czy Twoje posty są odpowiednie dla wszystkich członków, w tym młodszych osób.\n\n' +
                '**3️⃣ Kanały**\n' +
                'Korzystaj z odpowiednich kanałów do tematów, które chcesz poruszyć.\n' +
                'Unikaj spamu oraz offtopu. 🗣️\n\n' +
                '**4️⃣ Reklamy i spam**\n' +
                'Nie wolno reklamować innych serwerów, produktów ani usług bez zgody administracji. 🚫\n' +
                'Spamming (w tym wstawianie tych samych wiadomości w wielu kanałach) jest zabroniony.\n\n' +
                '**5️⃣ Nicki i avatary**\n' +
                'Twoje imię i avatar muszą być odpowiednie do atmosfery serwera. Unikaj obraźliwych i nieodpowiednich obrazów lub nazw.\n\n' +
                '**6️⃣ Prawa Administracji**\n' +
                'Administracja ma prawo do usuwania wiadomości, banowania użytkowników oraz podejmowania innych działań w celu utrzymania porządku. 🔨\n' +
                'Nie ingeruj w decyzje administracji – jeżeli masz jakiekolwiek pytania, skontaktuj się z nami bezpośrednio.\n\n' +
                '**7️⃣ Działania niezgodne z regulaminem**\n' +
                'Łamanie zasad skutkować będzie ostrzeżeniami, a w przypadku powtórzenia – banem.\n' +
                'Jeśli widzisz nieodpowiednie zachowanie, zgłoś to administracji. ✋\n\n' +
                '🎉 Ciesz się i baw się dobrze!\n' +
                'Zachowuj się odpowiedzialnie i dbajmy o naszą wspólną przestrzeń! Jeśli masz jakiekolwiek pytania, nie wahaj się zapytać administracji.'
            )
            .setThumbnail('https://example.com/your-image.png') // Możesz dodać URL do miniaturki
            .setFooter({ text: 'Regulamin serwera Discord' });

        // Wysyła embed do tego samego kanału, w którym wpisano komendę
        await message.reply({ embeds: [embed] });
    }
});

// Zaloguj bota do Discorda przy pomocy tokenu
client.login('MTMxNzM5NjgwNTM5NDM3MDY1Mg.G0QXDP.XFIa8cwbh3mqY8li7vpewCAaQrgtTE4TxrAuvo');
