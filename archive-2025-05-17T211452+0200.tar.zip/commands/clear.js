const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Usuwa określoną liczbę wiadomości młodszych niż 104 dni')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Liczba wiadomości do usunięcia (1-100)')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return interaction.reply({ content: 'Nie masz uprawnień do usuwania wiadomości!', ephemeral: true });
        }

        const amount = interaction.options.getInteger('amount');

        if (amount < 1 || amount > 100) {
            return interaction.reply({ content: 'Podaj liczbę od 1 do 100.', ephemeral: true });
        }

        const channel = interaction.channel;

        try {
            let messages = await channel.messages.fetch({ limit: amount * 2 }); // Pobieramy więcej, by przefiltrować stare wiadomości
            messages = messages.filter(msg => (Date.now() - msg.createdTimestamp) < 104 * 24 * 60 * 60 * 1000); // Filtrujemy starsze niż 104 dni

            const messagesToDelete = messages.first(amount); // Bierzemy pierwsze X wiadomości
            for (const msg of messagesToDelete) {
                await msg.delete();
            }

            await interaction.reply({ content: `Usunięto ${messagesToDelete.length} wiadomości młodszych niż 104 dni.`, ephemeral: true });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'Wystąpił błąd podczas usuwania wiadomości.', ephemeral: true });
        }
    },
};
