const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionsBitField, MessageFlags } = require('discord.js');

const roleIds = [
    '1336793696049561742',
    '1285250745658114168',
    '1354457484747870228',
    '1354464727404908664',
    '1354457440418267187'
]; // Lista r�l do nadania

module.exports = {
    data: new SlashCommandBuilder()
        .setName('weryfikacja')
        .setDescription('Tworzy wiadomo�� weryfikacyjn�.'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor('#c70003')
            .setTitle('Kr0xey Community - Weryfikacja')
            .setDescription('Kliknij poni�szy przycisk, aby si� zweryfikowa�.');

        const button = new ButtonBuilder()
            .setCustomId('verify')
            .setLabel('Zweryfikuj si�!')
            .setStyle(ButtonStyle.Success);

        const row = new ActionRowBuilder().addComponents(button);

        await interaction.reply({ embeds: [embed], components: [row] });
    },

    async handleButtonInteraction(interaction) {
        if (interaction.customId !== 'verify') return;

        const member = interaction.member;
        const botMember = interaction.guild.members.me;

        if (!botMember.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
            return interaction.reply({ 
                content: 'Nie mam uprawnie� do nadawania r�l!', 
                flags: MessageFlags.Ephemeral 
            });
        }

        // Dodajemy WSZYSTKIE role, kt�rych u�ytkownik jeszcze nie ma
        const rolesToAdd = [];

        // Sprawdzamy ka�d� rol� z listy
        for (const roleId of roleIds) {
            const role = interaction.guild.roles.cache.get(roleId);
            if (role && !member.roles.cache.has(role.id)) {
                rolesToAdd.push(role);
            }
        }

        if (rolesToAdd.length === 0) {
            return interaction.reply({ 
                content: 'Ju� masz wszystkie role!', 
                flags: MessageFlags.Ephemeral 
            });
        }

        try {
            // Dodajemy wszystkie brakuj�ce role
            await member.roles.add(rolesToAdd);
            await interaction.reply({ 
                content: 'Zosta�e� zweryfikowany i nadano ci wszystkie role!', 
                flags: MessageFlags.Ephemeral 
            });
        } catch (error) {
            console.error('B��d przy nadawaniu r�l:', error);
            await interaction.reply({ 
                content: 'Wyst�pi� b��d podczas nadawania r�l.', 
                flags: MessageFlags.Ephemeral 
            });
        }
    }
};
