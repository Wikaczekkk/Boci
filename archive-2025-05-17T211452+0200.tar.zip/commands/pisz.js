const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const allowedRoleIds = [
    '1336793637387767911' 
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('pisz')
        .setDescription('Bot wysyła podaną wiadomość')
        .addStringOption(option =>
            option.setName('wiadomosc')
                .setDescription('Treść wiadomości do wysłania')
                .setRequired(true)
                .setMaxLength(1000)),
    async execute(interaction) {
        const member = interaction.member;

        if (member.permissions.has(PermissionFlagsBits.Administrator)) {
            return await sendTheMessage(interaction);
        }


        const hasAllowedRole = member.roles.cache.some(role => allowedRoleIds.includes(role.id));

        if (!hasAllowedRole) {
            return await interaction.reply({ content: 'Nie masz uprawnień do użycia tej komendy!', ephemeral: true });
        }

        await sendTheMessage(interaction);
    },
};


async function sendTheMessage(interaction) {
    const message = interaction.options.getString('wiadomosc');
    await interaction.reply({ content: `Wysłano: ${message}`, ephemeral: true });
    await interaction.channel.send(message);
}
