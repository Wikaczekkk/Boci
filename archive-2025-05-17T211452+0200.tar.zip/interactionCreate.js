const { Events } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'open_ticket') {
            await interaction.reply({ content: '?? Tw�j ticket zosta� otwarty! U�yj `/ticket`', ephemeral: true });
        }
    },
};
